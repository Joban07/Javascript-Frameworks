// Import required modules
const fs = require('fs');
const express = require('express');
const cors = require('cors');

// Create an Express application
const app = express();

// Enable CORS for all origins
app.use(cors());

// Define route for '/'
app.get('/', (req, res) => {
  // Read file asynchronously
  fs.readFile('file.txt', 'utf8', (err, data) => {
    if (err) {
      // Log error if file reading fails
      console.error('Error reading file:', err);
      // Send 500 Internal Server Error response
      res.status(500).send('Internal Server Error');
      return;
    }
    // Serve file content as response
    res.status(200).send(data);
  });
});

// Define route for other requests (404 Not Found)
app.use((req, res) => {
  // Send 404 Not Found response
  res.status(404).send('Not Found');
});

// Define the port number for the server
const PORT = process.env.PORT || 3000;

// Start the Express server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
